import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Any

import os
import logging
import tempfile

from core.config import settings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s | %(asctime)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# Ensure static directory exists
os.makedirs("static", exist_ok=True)

# Try to import required modules that are heavy / optional at runtime
try:
    import cv2  # noqa: F401
    import pytesseract  # noqa: F401
    from PIL import Image  # noqa: F401
    import numpy as np  # noqa: F401
    from pdf2image import convert_from_path  # noqa: F401
except ImportError as e:
    logger.warning(
        f"Optional module missing at startup: {e}. "
        "Relevant endpoints will return an informative error."
    )

app = FastAPI(
    title=settings.APP_NAME,
    openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
)

# CORS middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files directory
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/favicon.ico")
async def favicon():
    """Serve favicon if present."""
    path = "static/favicon.ico"
    if os.path.exists(path):
        return FileResponse(path)
    # fallback: just return 204 if not present
    return JSONResponse(status_code=204, content=None)


@app.get("/")
async def root():
    return {
        "message": "Welcome to PyAutomate AI",
        "version": "1.0.0",
        "status": "operational",
    }


# -----------------------------
# RPA Endpoints
# -----------------------------
class WebAutomationTask(BaseModel):
    url: str
    selectors: Dict[str, str]


class ProductScrapingTask(BaseModel):
    url: str
    selectors: Dict[str, str]


@app.post("/api/v1/rpa/web-scrape")
async def web_scrape(task: WebAutomationTask):
    """
    Scrape data from a website using provided CSS selectors.
    """
    try:
        from rpa.web_automation import WebAutomation

        automation = WebAutomation(headless=True)
        automation.navigate(task.url)
        data = automation.extract_data(task.selectors)
        automation.close()
        return JSONResponse(content={"status": "success", "data": data})
    except Exception as e:
        logger.exception("Error in web_scrape")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/rpa/scrape-products")
async def scrape_products(task: ProductScrapingTask):
    """
    Scrape product information from an e-commerce website.
    """
    try:
        if not task.url.startswith("http"):
            raise HTTPException(
                status_code=400,
                detail="URL must start with http:// or https://",
            )

        from rpa.web_automation import WebAutomation

        automation = WebAutomation(headless=True)
        automation.navigate(task.url)
        products = automation.extract_products(task.selectors)
        automation.close()

        return JSONResponse(
            content={
                "status": "success",
                "count": len(products),
                "products": products,
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Error in scrape_products")
        raise HTTPException(status_code=500, detail=str(e))


# -----------------------------
# Document Processing Endpoints
# -----------------------------
@app.post("/api/v1/documents/process")
async def process_document(file: UploadFile = File(...)):
    """
    Process a document (image/PDF) and extract text and simple structured data.
    """
    try:
        from ai.document_processor import DocumentProcessor
    except ImportError as e:
        missing_module = str(e).split("'")[1] if "'" in str(e) else str(e)
        return JSONResponse(
            status_code=500,
            content={
                "detail": (
                    f"Missing required module or file: {missing_module}. "
                    "Ensure ai/document_processor.py exists and dependencies are installed."
                )
            },
        )

    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, file.filename)
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)

            processor = DocumentProcessor()

            if file.filename.lower().endswith(".pdf"):
                result = processor.process_pdf(file_path)
                return {
                    "status": "success",
                    "text": result["text"],
                    "structured_data": result["structured_data"],
                }
            else:
                text = processor.extract_text(file_path)
                structured_data = processor.extract_structured_data(file_path)
                return {
                    "status": "success",
                    "text": text,
                    "structured_data": structured_data,
                }
    except Exception as e:
        logger.exception("Error processing document")
        raise HTTPException(status_code=500, detail=str(e))


# -----------------------------
# Workflow Endpoints
# -----------------------------
class WorkflowRequest(BaseModel):
    name: str
    steps: List[Dict[str, Any]]


class WorkflowExecutionRequest(BaseModel):
    initial_data: Dict[str, Any]


@app.post("/api/v1/workflows/create")
async def create_workflow(workflow: WorkflowRequest):
    """
    Create a new workflow.
    """
    try:
        from workflows.workflow_engine import WorkflowEngine

        engine = WorkflowEngine()
        workflow_id = engine.create_workflow(workflow.name, workflow.steps)
        return {"status": "success", "workflow_id": workflow_id}
    except Exception as e:
        logger.exception("Error creating workflow")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/workflows/{workflow_id}/status")
async def get_workflow_status(workflow_id: str):
    """
    Get the current status of a workflow.
    """
    try:
        from workflows.workflow_engine import WorkflowEngine

        engine = WorkflowEngine()
        status = engine.get_workflow_status(workflow_id)
        return {"status": "success", "workflow": status}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("Error getting workflow status")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/workflows/{workflow_id}/execute")
async def execute_workflow(workflow_id: str, execution: WorkflowExecutionRequest):
    """
    Execute a workflow with initial data.
    """
    try:
        from workflows.workflow_engine import WorkflowEngine

        engine = WorkflowEngine()
        results = engine.execute_workflow(workflow_id, execution.initial_data)
        return {"status": "success", "results": results}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("Error executing workflow")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/test")
async def test_endpoint():
    """Simple test endpoint."""
    return {"status": "ok", "message": "Test endpoint is working"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "src.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
        log_level="info",
    )
